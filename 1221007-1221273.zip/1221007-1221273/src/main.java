import window.Menu;

public class main {

		public static void main (String [] args) {
			// initializes menu 
			Menu menu = new Menu("Escolha uma op��o");
		}
}
