package control;

public interface Observer {
	public void notify(Observed o);
}
